const lightbox = GLightbox({
  touchNavigation: true,
  loop: false,
  autoplayVideos: true,
});
